export default {
    primary: "#371a95",
    grey: "#ebebeb",
    white: "#fafafa",
}